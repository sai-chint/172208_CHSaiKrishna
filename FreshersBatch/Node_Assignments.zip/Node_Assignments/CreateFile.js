var fs = require('fs')
fs.writeFile('sai.txt','My Name is Sai Krishna',(err) => {
    if(err){
        console.log(err);
    }
    else{
        console.log('File Creation Successfully completed');
        fs.readFile('sai.txt','utf8',(err,File) => {
            if(err){
                console.log(File);
            }
            else{
                console.log(File);
            }
        });
    }
})
