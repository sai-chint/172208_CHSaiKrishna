/* var counter = function(arr){
    return 'this array contains '+arr.length+' elements';
};

module.exports = counter; */

/* var counter = function(arr){
    return 'this array contains '+arr.length+' elements';
};

module.exports.counter = counter; */ 


module.exports.counter = function(arr){
    return 'this array contains '+arr.length+' elements';
};