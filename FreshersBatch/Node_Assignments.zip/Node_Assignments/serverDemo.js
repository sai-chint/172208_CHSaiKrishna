

var http = require('http');
var server = http.createServer(function(req,res){
    console.log('req was made: '+req.url);
    res.writeHead(200,{'Content-Type':'text/plain'});
    res.end('hey sai');
});
server.listen(3059,'127.1.1.0');
console.log('done with server creating with port 3059');
