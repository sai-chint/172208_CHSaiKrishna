var http = require('http');
var port = 3000;

var server = http.createServer();

function createServer(request, response) {
  console.log(request.url)
  response.end('Hello SaiKrishna.')
}

function onListening() {
  console.log("Success, i'm listening from port: 3000")
}

server.on('request', createServer)
server.on('listening', onListening)

server.listen(3000);