var calc = require('./Calculator');
console.log(calc.sumCalc(3,5));