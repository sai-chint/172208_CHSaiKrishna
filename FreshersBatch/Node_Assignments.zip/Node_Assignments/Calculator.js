var sumCalc = function(a,b) {
    return 'sum is '+ +' ';
}

module.exports = sumCalc;