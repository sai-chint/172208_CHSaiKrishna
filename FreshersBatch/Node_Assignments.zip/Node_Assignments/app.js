//setting the time for o/p

/* setTimeout(function(){
    console.log('3 sec');
}, 3000); */

//printing the o/p after every interval

/* var time=0 ;
setInterval(function(){
    time+=2
    console.log(time+' sec passed');
},2000); */

//for specifying the o/p in an interval

var time=0 ;
var timer = setInterval(function(){
    time+=2
    console.log(time+' sec passed');
    if(time>5){
        clearInterval(timer);
    }
},2000);