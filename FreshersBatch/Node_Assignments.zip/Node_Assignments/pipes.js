var http = require('http');
var fs = require('fs');

var server = http.createServer(function(req,res){
    console.log('req was made: '+req.url);
    res.writeHead(200,{'Content-Type':'text/plain'});
    var myReadStream = fs.createReadStream(__dirname+'/sai.txt','utf8');

myReadStream.pipe(res);
  
});
server.listen(3059,'127.1.1.0');
console.log('done with server creating with port 3059');
