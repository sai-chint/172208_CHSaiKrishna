/* var events = require('events');

var myEmitter = new events.EventEmitter();

myEmitter.on('click',function(msg){
    console.log(msg);
});

myEmitter.emit('click','Hello Sai Krishna'); */

var events = require('events');
var util = require('util');

var Person = function(name){
    this.name = name;
};

util.inherits(Person, events.EventEmitter);

var sai = new Person('sai');
var krishna = new Person('krishna');
var chinna = new Person('chinna');

var people = [sai,krishna,chinna];

people.forEach(function(person){
    person.on('speak',function(msg){
        console.log(person.name + ' said: '+ msg);
    });
});

sai.emit('speak','My name');
krishna.emit('speak','My full name');
chinna.emit('speak','My nick name');