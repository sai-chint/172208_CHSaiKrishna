/* var coun = require('./stuff');
    console.log(coun(['sai','krishna'])); */

var coun = require('./stuff');
    console.log(coun.counter(['sai','krishna']));